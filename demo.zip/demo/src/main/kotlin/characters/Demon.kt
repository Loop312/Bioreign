package characters

/*
Strengths: TBD
Weaknesses: TBD
Unique Skill: TBD
*/
class Demon : Character() {
    override var race = "Demon"
    /*
    copy pasted from darkElf
    //Strengths
    override var spd = 15
    override var stealth = 15
    override var stamina = 15

    //weaknesses
    override var str = 5
    override var maxHp = 5
    override var hp = 5
    override var def = 5

    */
}