package characters

class NPC (race: Character) {
    var dialog = "placeholder"
}